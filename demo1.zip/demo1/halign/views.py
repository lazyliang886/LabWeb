import os
import plotly.graph_objs as go
import plotly.io as pio
from django.http import HttpResponse
from django.shortcuts import render
from matplotlib import pyplot as plt


# Create your views here.
def test(request):
    return render (request, "index.html")


def test1(request):
    if request.method == 'POST':
        outputfilename = request.POST.get ('outputfilename')
        t = request.POST.get ('t')
        c = request.POST.get ('c')
        Xmx = request.POST.get ('Xmx')
        s = request.POST.get ('s')
        h = request.POST.get ('h')
        v = request.POST.get ('v')
        type_of_graph = request.POST.get ('type_of_graph')
        left = int(request.POST.get ('left'))
        right = int(request.POST.get ('right'))
        top = int(request.POST.get ('top'))
        bottom = int(request.POST.get ('bottom'))
        inputfile = request.FILES['fileUpload']
        if t != "":
            t = " -t " + t
        if c != "":
            c = " -c " + c
        if Xmx != "":
            Xmx = " -Xmx " + Xmx
        if s != "False":
            s = " -s"
        else:
            s = ""
        if h != "False":
            h = " -h"
        else:
            h = ""
        if v != "False":
            v = " -v"
        else:
            v = ""
        with open ('datas/' + inputfile.name, 'wb') as f:
            f.write (inputfile.file.getvalue ())
        command = 'java -jar halign/HAlign-3.0.0_rc1.jar -o datas/' + outputfilename + t + c + Xmx + s + h + v + ' datas/' + inputfile.name
        print (command)
        os.system (command)
        responseFile=processData2img('datas/' + outputfilename,type_of_graph,left,right,top,bottom)
        if type_of_graph=="tail":
            return HttpResponse (open ('datas/' + responseFile))
        else:
            return HttpResponse (open('datas/' + responseFile,'rb').read(),content_type = "image/jpeg")
    return render (request, "testdemo1.html")


def processData2img(filename, type_of_graph, left, right, top, bottom):
    colorMap = {'A': 'black', 'B': 'grey', 'C': 'white', 'D': 'rosybrown', 'E': 'brown', 'F': 'red', 'G': 'mistyrose',
                'H': 'coral',
                'I': 'sienna', 'J': 'chocolate', 'K': 'tan', 'L': 'gold',
                'M': 'darkkhaki', 'N': 'olive', 'O': 'yellow', 'P': 'chartreuse', 'Q': 'palegreen', 'R': 'darkgreen',
                'S': 'turquoise',
                'T': 'cyan', 'U': 'deepskyblue', 'V': 'cornflowerblue', 'W': 'navy', 'X': 'darkorchid',
                'Y': 'lime', 'Z': 'fuchsia', '-': 'lightpink'}
    data = [[[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []],
            [[], []], [[], []], [[], []], [[], []], [[], []], [[], []],
            [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []], [[], []],
            [[], []]]
    print (len (data))
    if type_of_graph == "tail":
        with open (filename, 'r', encoding = 'utf-8') as f:
            for y, line in enumerate (f):
                for x, ch in enumerate (line):
                    if ch != '-' and ch != '\n' and left <= x <= right and bottom <= y <= top:
                        data[ord (ch) - ord ('A')][0].append (x)
                        data[ord (ch) - ord ('A')][1].append (y)
                    elif ch == '-' and left <= x <= right and bottom <= y <= top:
                        data[26][0].append (x)
                        data[26][1].append (y)
        fig = go.Figure ()
        for n, ch in enumerate (data):
            if n != 26:
                print (chr (n + ord ('A')))
                sca = go.Scatter (x = ch[0], y = ch[1], mode = 'markers',
                                  marker = dict (color = colorMap[chr (n + ord ('A'))], symbol = 'square'))
                fig.add_trace (sca)
            else:
                print (chr (n + ord ('A')))
                sca = go.Scatter (x = ch[0], y = ch[1], mode = 'markers',
                                  marker = dict (color = colorMap['-'], symbol = 'square'))
                fig.add_trace (sca)
        pio.write_html (fig, "datas/tmp.html")
        return "tmp.html"
    else:
        with open (filename, 'r', encoding = 'utf-8') as f:
            for y, line in enumerate (f):
                for x, ch in enumerate (line):
                    if ch != '-' and ch != '\n':
                        data[ord (ch) - ord ('A')][0].append (x)
                        data[ord (ch) - ord ('A')][1].append (y)
                    elif ch == '-':
                        data[26][0].append (x)
                        data[26][1].append (y)
        for n, ch in enumerate (data):
            if n != 26:
                plt.scatter (ch[0], ch[1], c = colorMap[chr (n + ord ('A'))], marker = 's')
            else:
                plt.scatter (ch[0], ch[1], c = colorMap['-'], marker = 's')
        # plt.legend ()
        plt.savefig ('datas/tmp.jpg')
        plt.axes ().get_xaxis ().set_visible (False)  # 隐藏x坐标轴
        plt.axes ().get_yaxis ().set_visible (False)  # 隐藏y坐标轴

        return "tmp.jpg"
