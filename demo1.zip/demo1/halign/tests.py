import matplotlib
import numpy as np
from django.test import TestCase
import plotly.graph_objs as go
import plotly.io as pio
from matplotlib import pyplot as plt


# Create your tests here.

def processData2img(filename):
    colorMap={'A':'black','B':'grey','C':'white','D':'rosybrown','E':'brown','F':'red','G':'mistyrose','H':'coral',
              'I':'sienna','J':'chocolate','K':'tan','L':'gold',
              'M':'darkkhaki','N':'olive','O':'yellow','P':'chartreuse','Q':'palegreen','R':'darkgreen','S':'turquoise',
              'T':'cyan','U':'deepskyblue','V':'cornflowerblue','W':'navy','X':'darkorchid',
              'Y':'lime','Z':'fuchsia','-':'lightpink'}
    data=[[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],
          [[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]],[[],[]]]
    print(len(data))
    l=0
    r=200
    down=0
    up=50
    with open(filename,'r',encoding = 'utf-8') as f:
        for y,line in enumerate(f):
            for x,ch in enumerate(line):
                if ch!='-' and ch!='\n'and l<=x<=r and down<=y<=up:
                    # print(ch)
                    # print(ord(ch)-ord('A'))
                    data[ord(ch)-ord('A')][0].append(x)
                    data[ord (ch) - ord ('A')][1].append (y)
                elif ch=='-' and l<=x<=r and down<=y<=up:
                    data[26][0].append(x)
                    data[26][1].append(y)
    # data=[]
    # with open (filename, 'r', encoding = 'utf-8') as f:
    #     for y,line in enumerate(f):
    #         seq=[]
    #         for x,ch in enumerate(line):
    #             seq.append(colorMap[ch])
    #         data.append(seq)
    # for seq in data:
    #     plt.scatter(np.arange(0,))
    # matplotlib.use ('SVG')
    fig=go.Figure()
    for n,ch in enumerate(data):
        if n!=26:
            print(chr(n+ord('A')))
            sca=go.Scatter(x=ch[0],y=ch[1],mode = 'markers',marker = dict(color=colorMap[chr(n+ord('A'))],symbol='square'))
            fig.add_trace(sca)
            # plt.scatter(ch[0],ch[1],c=colorMap[chr(n+ord('A'))],marker = 's')
        else:
            print (chr (n + ord ('A')))
            sca=go.Scatter (x = ch[0], y = ch[1], mode = 'markers', marker = dict(color=colorMap['-'],symbol='square'))
            fig.add_trace(sca)
            # plt.scatter (ch[0], ch[1], c = colorMap['-'], marker = 's')
    # plt.legend()
    # plt.savefig('../datas/figure1.png',dpi=10000)
    # plt.axes().get_xaxis().set_visible(False) # 隐藏x坐标轴
    # plt.axes().get_yaxis().set_visible(False) # 隐藏y坐标轴
    # plt.savefig('../datas/res.svg')
    # plt.show()
    # fig.show()
    pio.write_image(fig,"test.png")
    # fig.show()
processData2img('../datas/test.fasta.aln')